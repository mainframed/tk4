
#include "cmpsctst_stdinc.h"
#include "cmpscget.c"
