
#include "cmpsctst_stdinc.h"
#include "cmpsc_2012.c"
