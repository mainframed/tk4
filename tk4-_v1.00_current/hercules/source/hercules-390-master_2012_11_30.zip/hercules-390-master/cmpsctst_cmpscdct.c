
#include "cmpsctst_stdinc.h"
#include "cmpscdct.c"
