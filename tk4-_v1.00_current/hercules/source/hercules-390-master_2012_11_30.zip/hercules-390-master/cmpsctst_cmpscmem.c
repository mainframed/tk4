
#include "cmpsctst_stdinc.h"
#include "cmpscmem.c"
