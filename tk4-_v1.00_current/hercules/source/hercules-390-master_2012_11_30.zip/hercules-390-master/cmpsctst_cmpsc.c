
#include "cmpsctst_stdinc.h"
#include "cmpsc.c"
