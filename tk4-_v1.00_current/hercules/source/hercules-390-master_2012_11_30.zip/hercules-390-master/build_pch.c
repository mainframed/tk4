/* BUILD_PCH  (c)Copyright Ivan Warren, 2005-2012                    */
/*            Dummy module for building pre-compiled header files    */
/*                                                                   */
/*   Released under "The Q Public License Version 1"                 */
/*   (http://www.hercules-390.org/herclic.html) as modifications to  */
/*   Hercules.                                                       */

#include "hstdinc.h"
