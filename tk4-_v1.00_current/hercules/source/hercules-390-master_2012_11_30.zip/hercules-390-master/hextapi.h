/* HEXTAPI.H   (c) Copyright Roger Bowler & Others, 2005-2012        */
/*             Definition of Hercules External (public) APIs         */
/*                                                                   */
/*   Released under "The Q Public License Version 1"                 */
/*   (http://www.hercules-390.org/herclic.html) as modifications to  */
/*   Hercules.                                                       */

/*
        +-------------------------------------------------+
        |   This file originally written by Ivan Warren   |
        |   THE STATE OF THIS API IS NOT YET FINALIZED    |
        |   AND THEREFORE, THE INTERFACE MAY CHANGE       |
        +-------------------------------------------------+
*/

#ifndef _HEXTAPI_H_
#define _HEXTAPI_H_

// ZZ FIXME: do we even NEED this header any longer?!

#endif
