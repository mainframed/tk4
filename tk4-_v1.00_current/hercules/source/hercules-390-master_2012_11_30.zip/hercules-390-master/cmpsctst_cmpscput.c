
#include "cmpsctst_stdinc.h"
#include "cmpscput.c"
