SIMULA 67 (Version 12.00) Compiler and Runtime Environment
----------------------------------------------------------

This is the TK4- implementation of the SIMULA 67 distribution published
on http://www.edelweb.fr/Simula by Peter Sylvester, with sample programs
by Karel Babcicky.


Index:
------

README.txt         -- This file
simula.xmi         -- Distribution library, XMIT370 format


Installation:
-------------

1. Receive simula.xmi to a PDS (LRECL 80) using RECV370.
2. Follow the instructions in member $$README of the received PDS.

----------
Juergen Winkelmann, winkelmann@id.ethz.ch, 5.1.2014
