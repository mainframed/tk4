JRP Enhancements
================

Bug fixes and updates to Scott Vetter's JRP implementation
for MVS 3.8j, which is available from CBT file 755.


USAGE
=====

Unzip member jrpupdte.xmi from this ZIP archive and receive it into a
partitioned dataset using RECV370. See the comment header of member
JRPUDPT$ in the received PDS for further information.

10/26/2013 Juergen Winkelmann, winkelmann@id.ethz.ch
