Refer to the help.htm file before using JCC.
